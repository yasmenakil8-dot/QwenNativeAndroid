package com.example.qwennative

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatMessage(val role: String, val text: String)
data class LocalModel(val name: String, val uri: String)

class AppDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "qwen_native.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY, role TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE memories(id TEXT PRIMARY KEY, body TEXT NOT NULL, created INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE models(id TEXT PRIMARY KEY, name TEXT NOT NULL, uri TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun saveMessage(m: ChatMessage) {
        writableDatabase.insert("messages", null, ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("role", m.role)
            put("body", m.text); put("created", System.currentTimeMillis())
        })
    }
    fun readMessages(): List<ChatMessage> {
        val out = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery("SELECT role,body FROM messages ORDER BY created", null).use {
            while (it.moveToNext()) out += ChatMessage(it.getString(0), it.getString(1))
        }
        return out
    }
    fun addMemory(text: String) {
        writableDatabase.insert("memories", null, ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("body", text)
            put("created", System.currentTimeMillis()); put("pinned", 1)
        })
    }
    fun readMemories(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT body FROM memories ORDER BY created DESC", null).use {
            while (it.moveToNext()) out += it.getString(0)
        }
        return out
    }
    fun addModel(name: String, uri: String) {
        writableDatabase.insertWithOnConflict("models", null, ContentValues().apply {
            put("id", uri); put("name", name); put("uri", uri)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun readModels(): List<LocalModel> {
        val out = mutableListOf<LocalModel>()
        readableDatabase.rawQuery("SELECT name,uri FROM models ORDER BY name", null).use {
            while (it.moveToNext()) out += LocalModel(it.getString(0), it.getString(1))
        }
        return out
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDb(this)
        setContent { QwenApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QwenApp(db: AppDb) {
    val context = LocalContext.current
    var messages by remember { mutableStateOf(db.readMessages()) }
    var memories by remember { mutableStateOf(db.readMemories()) }
    var models by remember { mutableStateOf(db.readModels()) }
    var selectedModel by remember { mutableStateOf<String?>(models.firstOrNull()?.name) }
    var input by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("chat") }
    var dark by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("استورد نموذج GGUF للبدء") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "GGUF model"
            db.addModel(name, uri.toString())
            models = db.readModels()
            selectedModel = name
            notice = "تمت إضافة النموذج. يلزم ربط محرك llama.cpp الأصلي لتشغيل الاستدلال."
        }
    }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Qwen Native") },
                    actions = {
                        TextButton(onClick = { dark = !dark }) { Text(if (dark) "فاتح" else "داكن") }
                        TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("استيراد GGUF") }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == "chat", onClick = { tab = "chat" }, icon = {}, label = { Text("محادثة") })
                    NavigationBarItem(selected = tab == "models", onClick = { tab = "models" }, icon = {}, label = { Text("النماذج") })
                    NavigationBarItem(selected = tab == "memory", onClick = { tab = "memory" }, icon = {}, label = { Text("الذاكرة") })
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
                when (tab) {
                    "chat" -> {
                        Text(selectedModel?.let { "النموذج: $it" } ?: "لم يتم اختيار نموذج")
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(messages) { m ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement =
                                    if (m.role == "user") Arrangement.End else Arrangement.Start) {
                                    Surface(color = if (m.role == "user") MaterialTheme.colorScheme.secondaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(14.dp)) {
                                        Text(m.text, Modifier.padding(12.dp))
                                    }
                                }
                            }
                        }
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("اكتب رسالتك…") }
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(onClick = {
                                val q = input.trim()
                                if (q.isNotEmpty()) {
                                    val user = ChatMessage("user", q)
                                    db.saveMessage(user)
                                    messages = db.readMessages()
                                    input = ""
                                    val reply = ChatMessage(
                                        "assistant",
                                        "تم حفظ رسالتك. تشغيل النموذج محلياً غير مفعّل بعد: يجب دمج مكتبة llama.cpp/llama.android مع هذا المشروع."
                                    )
                                    db.saveMessage(reply)
                                    messages = db.readMessages()
                                }
                            }) { Text("إرسال") }
                        }
                    }
                    "models" -> {
                        Text("النماذج المحلية", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف نموذج") }
                        models.forEach { model ->
                            ListItem(
                                headlineContent = { Text(model.name) },
                                supportingContent = { Text(model.uri, maxLines = 1) },
                                trailingContent = {
                                    TextButton(onClick = { selectedModel = model.name }) { Text("اختيار") }
                                }
                            )
                        }
                    }
                    else -> {
                        Text("الذاكرة طويلة الأمد", style = MaterialTheme.typography.titleLarge)
                        var memoryInput by remember { mutableStateOf("") }
                        OutlinedTextField(memoryInput, { memoryInput = it }, Modifier.fillMaxWidth(),
                            placeholder = { Text("أضف معلومة لحفظها محلياً") })
                        Button(onClick = {
                            if (memoryInput.isNotBlank()) {
                                db.addMemory(memoryInput.trim())
                                memories = db.readMemories()
                                memoryInput = ""
                            }
                        }) { Text("حفظ المعلومة") }
                        memories.forEach { Text("• $it", Modifier.padding(vertical = 5.dp)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(notice, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
