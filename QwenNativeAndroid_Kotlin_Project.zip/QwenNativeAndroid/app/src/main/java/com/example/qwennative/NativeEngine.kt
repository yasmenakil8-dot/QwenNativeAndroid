package com.example.qwennative

object NativeEngine {
    init { System.loadLibrary("qwen_native") }
    external fun status(): String
}
