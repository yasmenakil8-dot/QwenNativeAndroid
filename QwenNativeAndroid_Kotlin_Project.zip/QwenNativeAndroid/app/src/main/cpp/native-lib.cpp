#include <jni.h>
#include <string>

// نقطة ربط JNI لمحرك الاستدلال الأصلي.
// لا توجد مكتبة llama.cpp مضمّنة في هذا المشروع حتى الآن.
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_qwennative_NativeEngine_status(JNIEnv* env, jobject) {
    std::string msg = "llama.cpp native backend is not linked";
    return env->NewStringUTF(msg.c_str());
}
