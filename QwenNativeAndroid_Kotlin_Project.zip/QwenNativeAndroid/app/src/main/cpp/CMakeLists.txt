cmake_minimum_required(VERSION 3.22.1)
project(qwen_native)
add_library(qwen_native SHARED native-lib.cpp)
find_library(log-lib log)
target_link_libraries(qwen_native ${log-lib})
# لإضافة الاستدلال الحقيقي: اربط مكتبة llama.cpp المبنية لـ Android/NDK
# وأضف include directories و target_link_libraries الخاصة بها.
